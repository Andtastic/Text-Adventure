list1 = ["String, Telepathy, Text, Caleb"]


def stringSave():
    return list1


input(stringSave(3))